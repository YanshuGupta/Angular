import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './admin/home.component';
import { NewBookComponent } from './admin/newBook.component';
import { NewUserComponent } from './admin/newUser.component';
import { NewCategoryComponent } from './admin/newCategory.component';
import { NewCustomerComponent } from './admin/newCustomer.component';
import { LoginComponent } from './app.logincomponent';
import { Logout } from './logoutcomponent';

const routes: Routes = [
	{path: '', component: LoginComponent},
	{path: 'home', component: HomeComponent},
	{path: 'newBook', component: NewBookComponent},
	{path: 'newUser', component: NewUserComponent},
	{path: 'newCategory', component: NewCategoryComponent},
	{path: 'newCustomer', component: NewCustomerComponent},
	{path: 'logout', component: Logout}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
