export class Admin {
  adminId: number;
  adminName: string;
  adminEmail: string;
  password: string;
}