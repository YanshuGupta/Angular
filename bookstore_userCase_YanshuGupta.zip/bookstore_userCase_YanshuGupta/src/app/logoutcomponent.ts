import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';

@Component({
  selector: 'logging-out',
  template: '<h1>logging out here</h1>',
  styleUrls: ['./app.component.css']
})

export class Logout implements OnInit {

	constructor(private router: Router) {	}

	ngOnInit() {
		if(confirm("logging out")){
			localStorage.clear();
		}
		this.router.navigate(['/']);
	};
	 
}