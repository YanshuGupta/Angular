import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';

import { AdminService } from './service/admin.service';

@Component({
selector: 'login-root',
templateUrl: './login.html',
styleUrls: ['./app.component.css']
})

export class LoginComponent{
	ngOnInit() {
		if(localStorage.getItem("key") != null){
			this.router.navigate(['/home']);
		}
		else{
			this.router.navigate(['/']);
		}
	};
	constructor(private router: Router, private adminService: AdminService) {
		
	}
	
	loginUser(email, password): void {
		
		this.adminService.loginUser(email+"/"+password).subscribe( data => { 
			if(data){
				alert("Login Successfull");
				localStorage.setItem("key", email);
				this.router.navigate(['/home']);
			}
			else{
				
				alert("Email or Password is incorrect");
			} 
		});
	};
}


