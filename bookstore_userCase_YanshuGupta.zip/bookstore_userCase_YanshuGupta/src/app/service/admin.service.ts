import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
 
import { Admin } from '../models/admin';

 
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class AdminService {
 
	constructor(private http:HttpClient) {}

	private url = 'http://localhost:8092'

	public getUsers() {
		return this.http.get<Admin[]>(this.url + '/getAllUsers');
	}

	public createUser(admin) {
		return this.http.post(this.url + '/createUser', admin);
	}

	public deleteUser(admin) {
		return this.http.delete(this.url + '/deleteUser' + "/"+ admin.adminId);
	}
	
	public loginUser(emailAndPassword) {
		return this.http.post(this.url + '/loginUser' + "/"+ emailAndPassword, null);
	}
}