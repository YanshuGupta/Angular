import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';

import { Admin } from '../models/admin';
import { AdminService } from '../service/admin.service';

@Component({
  selector: 'home-root',
  templateUrl: './home.component.html',
  styleUrls: ['./app.component.css']
})
export class HomeComponent implements OnInit {
	
	key: any;
	users: Admin[];
	
	constructor(private router: Router, private adminService: AdminService) {  }
 
	ngOnInit() {
		
		if(localStorage.getItem("key") != null){
			
			this.adminService.getUsers().subscribe(data => {this.users=data;});
		}
		else{
			this.router.navigate(['/']);
		}
	};
	
	deleteUser(user: Admin): void {
		if(confirm("Are You want to Delete User with Id "+user.adminId)){
			this.adminService.deleteUser(user).subscribe( data => {this.users = this.users.filter(u => u !== user); })
		}
	};
	
	
	 
}
