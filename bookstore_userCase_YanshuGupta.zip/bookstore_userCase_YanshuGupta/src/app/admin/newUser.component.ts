import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { Admin } from '../models/admin';
import { AdminService } from '../service/admin.service';

@Component({
  selector: 'newUser-root',
  templateUrl: 'newUser.Component.html',
  styleUrls: ['./app.component.css']
})
export class NewUserComponent {

	user: Admin = new Admin();

	constructor(private router: Router, private adminService: AdminService) {	}
	
	ngOnInit() {
		if(localStorage.getItem("key") != null){
			this.router.navigate(['/newUser']);
		}
		else{
			this.router.navigate(['/']);
		}
	};
	createUser(): void {
		if(this.user.adminName == null){
			alert("Please Enter Valid name");
			return;
		}
		if(this.user.adminEmail == null){
			alert("Please Enter Valid Email");
			return;
		}
		if(this.user.password == null){
			alert("Please Enter Valid Password");
			return;
		}
		this.adminService.createUser(this.user).subscribe( data => { alert("User created successfully.");});

	};

}