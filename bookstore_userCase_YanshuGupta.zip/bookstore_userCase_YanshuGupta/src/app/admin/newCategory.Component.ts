import { Component } from '@angular/core';

@Component({
  selector: 'newCategory-root',
  templateUrl: './UnderConstruction.html',
  styleUrls: ['./app.component.css']
})
export class NewCategoryComponent {
 
  
}