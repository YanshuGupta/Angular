import { Component } from '@angular/core';

@Component({
  selector: 'newCustomer-root',
  templateUrl: './UnderConstruction.html',
  styleUrls: ['./app.component.css']
})
export class NewCustomerComponent {
 
  
}