import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule} from "@angular/common/http";
import { StorageServiceModule} from 'angular-webstorage-service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './app.logincomponent';
import { HomeComponent } from './admin/home.component';
import { NewBookComponent } from './admin/newBook.component';
import { NewUserComponent } from './admin/newUser.component';
import { NewCategoryComponent } from './admin/newCategory.component';
import { NewCustomerComponent } from './admin/newCustomer.component';
import { AdminService } from './service/admin.service';
import { Logout } from './logoutcomponent';

@NgModule({
  declarations: [
    AppComponent, HomeComponent, NewBookComponent, NewUserComponent, NewCategoryComponent, NewCustomerComponent, LoginComponent, Logout
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
	HttpClientModule,
    FormsModule,
	StorageServiceModule
  ],
  providers: [AdminService],
  bootstrap: [AppComponent]
})
export class AppModule { }
