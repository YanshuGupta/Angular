package com.capgemini.capstore.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Admin;
import com.capgemini.capstore.main.exception.EmailAlreadyExistsException;
import com.capgemini.capstore.main.service.IAdminService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class MyController {

	@Autowired
	IAdminService service;

	@RequestMapping(method = RequestMethod.GET, value = "/getAllUsers")
	public List<Admin> getAllUsers() {

		return service.getAllUsers();
	}

	@RequestMapping(method = RequestMethod.POST, value = "/createUser")
	public Admin createUser(@RequestBody Admin admin) {
		if(validateAdmin(admin)) {
			try {
				return service.createUser(admin);
			} catch (EmailAlreadyExistsException e) {
				// TODO Auto-generated catch block
				System.err.println(e.getMessage());
			}
		}
		return null;
	}

	private boolean validateAdmin(Admin admin) {
		if(admin.getAdminEmail() == null || admin.getAdminEmail().equals("")) {
			return false;
		}
		if(admin.getPassword() == null || admin.getPassword().equals("")) {
			return false;
		}
		if(admin.getAdminName() == null || admin.getAdminName().equals("")) {
			return false;
		}
		return true;
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/deleteUser/{adminId}")
	public Admin deleteUser(@PathVariable int adminId) {

		return service.deleteUser(adminId);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/loginUser/{email}/{password}")
	public boolean loginUser(@PathVariable String email, @PathVariable String password) {

		return service.loginUser(email, password);
	}
}
