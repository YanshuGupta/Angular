package com.capgemini.capstore.util;

import org.apache.commons.codec.binary.Hex;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

public final class PBKDF2 {

	public static String encryptPassword(String password) throws UnsupportedEncodingException {

		byte[] hashedBytes = hashPassword(password.toCharArray());
		String hashedString = Hex.encodeHexString(hashedBytes);

		return hashedString;
	}

	public static byte[] hashPassword(final char[] password) {

		int iterations = 10000;
		int keyLength = 512;
		byte[] salt = "1234".getBytes();

		try {
			SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
			PBEKeySpec spec = new PBEKeySpec(password, salt, iterations, keyLength);
			SecretKey key = skf.generateSecret(spec);
			byte[] res = key.getEncoded();
			return res;
		} catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
			throw new RuntimeException(e);
		}
	}
}